import { EventEmitter } from 'events';
import { Config } from '../config/env';
import { Market } from '../types';
import { MarketCache } from '../storage/marketCache';
import { Logger } from '../utils/logger';

export interface DiscoveryEvents {
  newMarket: (market: Market) => void;
  tick: (markets: Market[]) => void;
}

export class DiscoveryService extends EventEmitter {
  private timer?: NodeJS.Timeout;
  private pageSize = 100;

  constructor(
    private config: Config,
    private cache: MarketCache,
    private logger: Logger,
  ) {
    super();
  }

  start() {
    this.logger.info('Starting Gamma discovery');
    this.poll();
    this.timer = setInterval(() => this.poll(), this.config.pollIntervalSeconds * 1000);
  }

  stop() {
    if (this.timer) clearInterval(this.timer);
  }

  private parseStringArray(value: unknown): string[] {
    if (Array.isArray(value)) {
      return value.filter((x) => typeof x === 'string' && x.length > 0);
    }

    if (typeof value === 'string' && value.trim().length > 0) {
      try {
        const parsed = JSON.parse(value);
        if (Array.isArray(parsed)) {
          return parsed.filter((x) => typeof x === 'string' && x.length > 0);
        }
      } catch {}
    }

    return [];
  }

  private async poll(page = 1): Promise<void> {
    try {
      const url = new URL('/markets', this.config.gammaBaseUrl);
      url.searchParams.set('page', String(page));
      url.searchParams.set('limit', String(this.pageSize));
      url.searchParams.set('active', 'true');
      url.searchParams.set('closed', 'false');
      url.searchParams.set('archived', 'false');

      const response = await fetch(url.toString());
      if (!response.ok) throw new Error(`Gamma API responded ${response.status}`);

      const data = await response.json();
      const rawMarkets = (data?.markets || data || []) as any[];

      const markets: Market[] = rawMarkets.map((m: any) => {
        const marketId = m.id || m.market_id || m.slug;

        const tokenIds = this.parseStringArray(m.clobTokenIds);

        return {
          id: marketId,
          question: m.question || m.title || 'Mercado sem nome',
          slug: m.slug,
          url: m.url || (m.slug ? `https://polymarket.com/market/${m.slug}` : undefined),
          createdAt: m.creation_time,
          ...(tokenIds.length > 0 ? { tokenIds } : {}),
        } as Market;
      });

      const withTokens = markets.filter((m: any) => Array.isArray((m as any).tokenIds) && (m as any).tokenIds.length > 0).length;
      this.logger.info('Discovery tick', { count: markets.length, withTokens });

      const sample = markets.find((m: any) => Array.isArray((m as any).tokenIds) && (m as any).tokenIds.length > 0) as any;
      if (sample) this.logger.info('Discovery sample', { marketId: sample.id, tokenId: sample.tokenIds[0] });

      this.emit('tick', markets);

      for (const market of markets) {
        if (!market.id) continue;

        if (!this.cache.has(market.id)) {
          this.cache.add(market.id);
          const tokenCount = Array.isArray((market as any).tokenIds) ? (market as any).tokenIds.length : 0;
          this.logger.info('New market discovered', { marketId: market.id, tokenCount });
          this.emit('newMarket', market);
        }
      }

      if (rawMarkets.length === this.pageSize) {
        await this.poll(page + 1);
      }
    } catch (error) {
      this.logger.error('Discovery error', { error: (error as Error).message });
    }
  }
}

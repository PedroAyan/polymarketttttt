import WebSocket from 'ws';
import { Config } from '../config/env';
import { Logger } from '../utils/logger';
import { MarketMetricsEngine } from '../metrics/engine';
import { MarketOrderBook, Trade } from '../types';

export type MarketUpdateHandler = (marketId: string) => void;

export class ClobClient {
  private ws?: WebSocket;
  private monitoredMarkets = new Set<string>();
  private reconnectAttempts = 0;
  private reconnectTimer?: NodeJS.Timeout;

  constructor(
    private config: Config,
    private metrics: MarketMetricsEngine,
    private logger: Logger,
    private onMarketUpdated?: MarketUpdateHandler,
  ) {}

  start() {
    const url = this.ensureMarketWsUrl(this.config.clobWsUrl);

    this.logger.info('Connecting to CLOB WebSocket', { url });
    this.ws = new WebSocket(url);

    this.ws.on('open', () => {
      this.logger.info('CLOB WebSocket connected');
      this.reconnectAttempts = 0;
      this.subscribeInitial();
    });

    this.ws.on('message', (data) => this.handleMessage(data.toString()));

    this.ws.on('close', () => {
      this.logger.warn('CLOB WebSocket closed, scheduling reconnect');
      this.scheduleReconnect();
    });

    this.ws.on('error', (err) => {
      this.logger.error('CLOB WebSocket error', { error: err.message });
      this.ws?.close();
    });
  }

  stop() {
    if (this.reconnectTimer) clearTimeout(this.reconnectTimer);
    this.ws?.close();
  }

  setMarkets(marketIds: string[]) {
    const next = new Set(marketIds.slice(0, this.config.maxMonitoredMarkets));
    const prev = this.monitoredMarkets;

    this.monitoredMarkets = next;

    if (!this.ws || this.ws.readyState !== WebSocket.OPEN) return;

    const toSubscribe: string[] = [];
    const toUnsubscribe: string[] = [];

    for (const id of next) {
      if (!prev.has(id)) toSubscribe.push(id);
    }

    for (const id of prev) {
      if (!next.has(id)) toUnsubscribe.push(id);
    }

    this.logger.info('setMarkets applied', {
      toSubscribe: toSubscribe.length,
      toUnsubscribe: toUnsubscribe.length,
      total: this.monitoredMarkets.size,
    });

    if (toSubscribe.length > 0) this.sendOperation('subscribe', toSubscribe);
    if (toUnsubscribe.length > 0) this.sendOperation('unsubscribe', toUnsubscribe);
  }

  private ensureMarketWsUrl(baseUrl: string) {
    const trimmed = (baseUrl || '').trim();

    if (!trimmed) return 'wss://ws-subscriptions-clob.polymarket.com/ws/market';

    const noTrailing = trimmed.endsWith('/') ? trimmed.slice(0, -1) : trimmed;

    if (noTrailing.endsWith('/market') || noTrailing.endsWith('/user')) return noTrailing;

    return `${noTrailing}/market`;
  }

  private subscribeInitial() {
    if (!this.ws || this.ws.readyState !== WebSocket.OPEN) return;

    const assets = Array.from(this.monitoredMarkets);
    if (assets.length === 0) return;

    const payload = { type: 'market', assets_ids: assets };
    this.ws.send(JSON.stringify(payload));
    this.logger.info('Subscribed to assets (initial)', { count: assets.length });
  }

  private sendOperation(operation: 'subscribe' | 'unsubscribe', assetIds: string[]) {
    if (!this.ws || this.ws.readyState !== WebSocket.OPEN) return;

    const payload = { operation, assets_ids: assetIds };
    this.ws.send(JSON.stringify(payload));
    this.logger.info('WS operation sent', { operation, count: assetIds.length });
  }

  private scheduleReconnect() {
    if (this.reconnectTimer) return;

    const delay = Math.min(30000, 1000 * Math.pow(2, this.reconnectAttempts++));
    this.reconnectTimer = setTimeout(() => {
      this.reconnectTimer = undefined;
      this.start();
    }, delay);
  }

  private handleMessage(raw: string) {
    if (!raw) return;

    let msg: any;

    try {
      if (raw[0] === '"') {
        msg = JSON.parse(JSON.parse(raw));
      } else if (raw[0] === '{') {
        msg = JSON.parse(raw);
      } else {
        this.logger.warn('Non-JSON WS message', { raw: String(raw).slice(0, 200) });
        return;
      }
    } catch (error) {
      this.logger.warn('WS parse failed', { raw: String(raw).slice(0, 200) });
      return;
    }

    const type = msg.type || msg.event;
    if (!type) return;

    switch (type) {
      case 'l2':
      case 'book':
        this.handleOrderBook(msg);
        break;
      case 'best_bid_ask':
      case 'bb':
        this.handleBestBidAsk(msg);
        break;
      case 'trade':
        this.handleTrade(msg);
        break;
      case 'new_market':
        this.logger.info('New market from stream', { marketId: msg.marketId || msg.market_id });
        break;
      default:
        break;
    }
  }

  private resolveAssetId(msg: any) {
    return msg.asset_id || msg.assetId || msg.marketId || msg.market_id;
  }

  private handleOrderBook(msg: any) {
    const assetId = this.resolveAssetId(msg);
    if (!assetId || !this.monitoredMarkets.has(assetId)) return;

    const bids: MarketOrderBook['bids'] = (msg.bids || msg.data?.bids || []).map((b: any) => ({
      price: Number(b[0] ?? b.price),
      size: Number(b[1] ?? b.size),
    }));

    const asks: MarketOrderBook['asks'] = (msg.asks || msg.data?.asks || []).map((a: any) => ({
      price: Number(a[0] ?? a.price),
      size: Number(a[1] ?? a.size),
    }));

    this.metrics.updateOrderBook(assetId, { bids, asks });
    this.onMarketUpdated?.(assetId);
  }

  private handleBestBidAsk(msg: any) {
    const assetId = this.resolveAssetId(msg);
    if (!assetId || !this.monitoredMarkets.has(assetId)) return;

    const bids: MarketOrderBook['bids'] = msg.bestBid
      ? [{ price: Number(msg.bestBid), size: Number(msg.bestBidSize || 1) }]
      : [];

    const asks: MarketOrderBook['asks'] = msg.bestAsk
      ? [{ price: Number(msg.bestAsk), size: Number(msg.bestAskSize || 1) }]
      : [];

    this.metrics.updateOrderBook(assetId, { bids, asks });
    this.onMarketUpdated?.(assetId);
  }

  private handleTrade(msg: any) {
    const assetId = this.resolveAssetId(msg);
    if (!assetId || !this.monitoredMarkets.has(assetId)) return;

    const trades: Trade[] = [
      {
        id: msg.id || msg.trade_id || `${msg.timestamp}-${msg.price}-${msg.size}`,
        price: Number(msg.price),
        size: Number(msg.size),
        side: msg.side === 'sell' ? 'sell' : 'buy',
        timestamp: Number(msg.timestamp || Date.now()),
      },
    ];

    this.metrics.updateTrades(assetId, trades);
    this.onMarketUpdated?.(assetId);
  }
}
